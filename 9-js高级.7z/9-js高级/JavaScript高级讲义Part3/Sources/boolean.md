#Boolean对象
##Boolean 对象方法

|方法|描述|
|--|--|
|toString()|把逻辑值转换为字符串，并返回结果。|
|valueOf()|返回 Boolean 对象的原始值。|
