# JavaScript总复习
## JavaScript基础复习
## 面向对象
### 面向对象的概念，基础理论
## JavaScript高级知识