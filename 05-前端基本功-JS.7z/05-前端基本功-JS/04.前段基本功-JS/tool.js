/**
 * Created by Lenovo on 2016/8/24.
 */
alert("我是外链式");