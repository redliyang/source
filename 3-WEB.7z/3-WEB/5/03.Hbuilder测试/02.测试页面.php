<?php
//	file_get_contents('12');

echo '123';

// php 有提示

?>