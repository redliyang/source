﻿# touch事件

标签（空格分隔）： 移动web

---


![前端与移动开发学院][1]
>移动端使用的是touch事件,但是并不能直接通过`ontouch`等语法访问,需要使用`addEventListener`进行绑定


## 可选事件

* **touchstart:**手指触摸时触发
* **touchmove:**手指在屏幕上滑动时连续触发
* **touchend:**当手指离开屏幕时触发。
* **touchcancel:**系统停止跟踪触摸时候会触发。(这个事件使用较少,了解即可)

* 事件参数中 能够获取移动的一些属性

```
dom.addEventListener('touchstart',function(e){
    console.log(e.targetTouches); //目标元素的所有当前触摸
    console.log(e.changedTouches);//最新更改的所有触摸
    console.log(e.touches);//所有的触摸
})
```





  [1]: http://static.zybuluo.com/antumuFish/xfnngpb23mze67n7y3y9ir3l/desk.jpg
